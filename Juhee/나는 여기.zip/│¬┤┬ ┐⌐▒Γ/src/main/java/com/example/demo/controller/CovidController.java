package com.example.demo.controller;

import com.example.demo.domain.User;
import com.example.demo.service.CovidService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.servlet.view.RedirectView;

import javax.servlet.http.HttpServletResponse;
import java.util.*;

import static org.springframework.web.context.request.RequestAttributes.SCOPE_REQUEST;

@RestController
public class CovidController {

    @Autowired
    private CovidService covidService;

    @PostMapping(value = "/covid")
    public void AlertCovid(NativeWebRequest webRequest, @RequestBody HashMap<String,String> map)
    {

        String uid=webRequest.getAttribute("user_id", SCOPE_REQUEST).toString();
        Date date=new Date(map.get("date"));
        List<String> alertUser=covidService.AlertCovid(uid,date);
        // 알람 발생

//        RedirectView redirectView = new RedirectView();
//        redirectView.setUrl("http://www.naver.com");


    }

    @GetMapping(value = "/covid")
    public Object data_api()
    {
        try {
            ObjectMapper objectMapper=new ObjectMapper();
            String data=covidService.data_api();
            System.out.println("controller "+ data);
            System.out.println("controller "+objectMapper.convertValue(data,Object.class) );

            return objectMapper.convertValue(data,Object.class);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return new Object();
    }


}
